class DestsGuoneis < ActiveRecord::Base
end
