class ChujingsDests < ActiveRecord::Base
end
