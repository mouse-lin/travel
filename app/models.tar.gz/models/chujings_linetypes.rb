class ChujingsLinetypes < ActiveRecord::Base
end
