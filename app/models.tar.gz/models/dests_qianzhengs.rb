class DestsQianzhengs < ActiveRecord::Base
end
