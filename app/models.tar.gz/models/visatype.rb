class Visatype < ActiveRecord::Base
end
