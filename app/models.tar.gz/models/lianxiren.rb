class Lianxiren < ActiveRecord::Base
  has_many :lines
end
