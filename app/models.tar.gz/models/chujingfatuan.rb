class Chujingfatuan < ActiveRecord::Base
  belongs_to :chujing
  belongs_to :star
end
