class House < ActiveRecord::Base
  has_many :zhiyoufatuans
end
