class Chufa < ActiveRecord::Base
end
