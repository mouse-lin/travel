class LinesLinetypes < ActiveRecord::Base
end
