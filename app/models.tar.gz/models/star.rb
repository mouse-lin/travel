class Star < ActiveRecord::Base
end
