class DestsLines < ActiveRecord::Base
end
