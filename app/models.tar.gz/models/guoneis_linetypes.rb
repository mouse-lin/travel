class GuoneisLinetypes < ActiveRecord::Base
end
