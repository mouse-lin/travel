class Linename < ActiveRecord::Base
end
