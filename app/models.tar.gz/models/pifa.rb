class Pifa < ActiveRecord::Base
end
