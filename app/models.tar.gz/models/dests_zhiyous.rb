class DestsZhiyous < ActiveRecord::Base
end
