class LinetypesZhiyous < ActiveRecord::Base
end
